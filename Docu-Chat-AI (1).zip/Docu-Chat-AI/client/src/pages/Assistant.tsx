import { MainLayout } from "@/components/layout/MainLayout";
import { useState } from "react";
import { Send, Bot, User, Mic, Paperclip, MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  time: string;
}

export default function Assistant() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, role: "assistant", content: "Hello John. I've analyzed your schedule. You have a meeting in 2 hours. Would you like me to prepare a briefing?", time: "09:00 AM" },
    { id: 2, role: "user", content: "Yes, please. Also, remind me to buy groceries later.", time: "09:01 AM" },
    { id: 3, role: "assistant", content: "Understood. I've added 'Buy groceries' to your task list for 6:00 PM. For the meeting briefing, I'm pulling the latest project documents now...", time: "09:01 AM" },
  ]);

  const handleSend = () => {
    if (!input.trim()) return;
    const newMsg: Message = {
      id: messages.length + 1,
      role: "user",
      content: input,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages([...messages, newMsg]);
    setInput("");
    
    // Mock response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: prev.length + 1,
        role: "assistant",
        content: "I've processed that request. Is there anything else you need help with?",
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }]);
    }, 1000);
  };

  return (
    <MainLayout>
      <div className="flex h-[calc(100vh-4rem)] gap-6">
        {/* Sidebar for Tasks/History */}
        <div className="hidden lg:flex w-80 flex-col gap-4">
           <div className="glass-card flex-1 rounded-xl p-4 flex flex-col">
             <div className="flex items-center justify-between mb-4">
               <h3 className="font-display font-semibold">Active Tasks</h3>
               <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">4 Pending</span>
             </div>
             <div className="space-y-3">
               {[
                 { title: "Buy groceries", time: "Today, 6:00 PM", priority: "medium" },
                 { title: "Finish API Documentation", time: "Tomorrow, 10:00 AM", priority: "high" },
                 { title: "Call Mom", time: "Sunday", priority: "low" },
                 { title: "Review PR #42", time: "Today, 2:00 PM", priority: "high" },
               ].map((task, i) => (
                 <div key={i} className="p-3 rounded-lg bg-background/50 border border-border hover:border-primary/50 transition-colors cursor-pointer">
                    <div className="flex justify-between items-start mb-1">
                      <p className="font-medium text-sm">{task.title}</p>
                      <div className={`h-2 w-2 rounded-full ${task.priority === 'high' ? 'bg-red-500' : task.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'}`} />
                    </div>
                    <p className="text-xs text-muted-foreground">{task.time}</p>
                 </div>
               ))}
             </div>
             
             <Button variant="outline" className="mt-auto w-full border-primary/20 hover:bg-primary/10 hover:text-primary">
               View All Tasks
             </Button>
           </div>
           
           <div className="glass-card h-1/3 rounded-xl p-4">
              <h3 className="font-display font-semibold mb-4">Memory Bank</h3>
              <p className="text-xs text-muted-foreground italic">"Project Alpha deadline is Friday"</p>
              <p className="text-xs text-muted-foreground italic mt-2">"Prefer dark mode UI"</p>
              <p className="text-xs text-muted-foreground italic mt-2">"Allergic to peanuts"</p>
           </div>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col glass-card rounded-xl overflow-hidden border-primary/20 shadow-[0_0_30px_rgba(0,0,0,0.3)]">
          <div className="p-4 border-b border-border flex items-center justify-between bg-background/30 backdrop-blur-xl">
             <div className="flex items-center gap-3">
               <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/50">
                 <Bot className="h-6 w-6 text-primary" />
               </div>
               <div>
                 <h2 className="font-display font-bold">Nexus AI</h2>
                 <p className="text-xs text-primary animate-pulse flex items-center gap-1">
                   <span className="h-1.5 w-1.5 rounded-full bg-primary inline-block" />
                   Online & Ready
                 </p>
               </div>
             </div>
             <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-foreground">
               <MoreVertical className="h-5 w-5" />
             </Button>
          </div>

          <ScrollArea className="flex-1 p-4 bg-gradient-to-b from-transparent to-background/20">
            <div className="space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    "flex w-full",
                    msg.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  <div className={cn(
                    "flex gap-3 max-w-[80%]",
                    msg.role === "user" ? "flex-row-reverse" : "flex-row"
                  )}>
                    <div className={cn(
                      "h-8 w-8 rounded-full flex items-center justify-center shrink-0 mt-1",
                      msg.role === "user" ? "bg-secondary/20 text-secondary" : "bg-primary/20 text-primary"
                    )}>
                      {msg.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                    </div>
                    
                    <div className={cn(
                      "p-4 rounded-2xl text-sm shadow-sm",
                      msg.role === "user" 
                        ? "bg-secondary text-white rounded-tr-none" 
                        : "bg-card border border-border text-foreground rounded-tl-none"
                    )}>
                      <p className="leading-relaxed">{msg.content}</p>
                      <p className={cn(
                        "text-[10px] mt-2 opacity-70",
                         msg.role === "user" ? "text-white" : "text-muted-foreground"
                      )}>{msg.time}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="p-4 border-t border-border bg-background/30 backdrop-blur-xl">
            <div className="flex items-center gap-2 bg-background/50 border border-input rounded-full px-4 py-2 focus-within:ring-2 focus-within:ring-primary/50 focus-within:border-primary transition-all">
              <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full text-muted-foreground hover:text-primary">
                <Paperclip className="h-4 w-4" />
              </Button>
              <Input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Ask Nexus anything..." 
                className="flex-1 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 px-0 h-9"
              />
              <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full text-muted-foreground hover:text-primary">
                <Mic className="h-4 w-4" />
              </Button>
              <Button 
                onClick={handleSend}
                size="icon" 
                className="h-8 w-8 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_10px_rgba(34,211,238,0.4)]"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
