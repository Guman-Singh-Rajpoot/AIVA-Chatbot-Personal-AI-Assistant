import { MainLayout } from "@/components/layout/MainLayout";
import { useState, useRef, useEffect } from "react";
import { Phone, Video, MoreVertical, Send, Sparkles, MessageCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Message {
  id: number;
  sender: string;
  content: string;
  time: string;
  type: "sent" | "received" | "typing";
}

const suggestedTopics = [
  "Who are you?",
  "Tell me about JNV",
  "What skills do you have?",
  "Tell me about your projects",
  "NCC & Awards?"
];

const keywordResponses: { [key: string]: string[] } = {
  // Introduction questions
  "who|name|introduce": [
    "I'm Guman Singh Rajpoot, a B.Tech Computer Science Engineering student at Sitare University (SRMU), Lucknow, graduating May 2027. I'm a 100% scholarship holder passionate about full-stack development, AI/ML, and building scalable applications! 🚀",
    "Hi! I'm Guman Singh Rajpoot from JNV Mahoba background, now a B.Tech CSE student at Sitare University with 100% scholarship. I'm dedicated to becoming a skilled software engineer in backend development and AI-driven systems! 🎓"
  ],
  
  // School/JNV questions
  "school|jnv|jawahar|navodaya|mahoba|high school|intermediate": [
    "I studied at Jawahar Navodaya Vidyalaya (JNV), Mahoba - an institution known for academic discipline and holistic development! 📚\n\nResults:\n🏆 High School: 80%\n🏆 Intermediate: 84%\n\nJNV helped me develop:\n✨ Problem-solving skills\n✨ Self-discipline and leadership\n✨ Adaptability in competitive environments\n\nThese qualities continue to shape my academic and professional growth!"
  ],

  // NCC & Awards questions
  "ncc|award|certificate|recognition|achievement": [
    "I'm proud to be an NCC 'B' Certificate holder! 🎖️\n\nThe NCC experience has instilled:\n💪 Leadership qualities\n💪 Teamwork and discipline\n💪 Physical and mental resilience\n\nI also hold a 100% B.Tech Computer Science Scholarship at Sitare University, which reflects my academic excellence and commitment to growth! 🏅"
  ],

  // Scholarship questions
  "scholarship|award|merit|academic": [
    "I'm honored to be a 100% B.Tech Computer Science Scholarship recipient at Sitare University! 🎓✨\n\nThis achievement reflects my dedication to academic excellence and continuous learning. It's a testament to the strong foundation I built at JNV and my commitment to becoming an excellent software engineer! 💪"
  ],

  // Skills questions
  "skills|expertise|proficient": [
    "I'm skilled in:\n\n🐍 Languages: Python, Java, JavaScript, TypeScript\n⚛️ Frontend: React, HTML/CSS, Tailwind CSS\n🗄️ Backend: Node.js, FastAPI, Django, Flask\n🗄️ Databases: PostgreSQL, MySQL\n🛠️ Tools: REST APIs, Git, GitHub\n📊 Data: Pandas, NumPy, Chart.js\n\nI focus on clean, scalable architecture with strong problem-solving foundation!"
  ],

  // Education questions
  "education|study|university|college|course": [
    "I'm pursuing B.Tech in Computer Science Engineering at Sitare University (SRMU), Lucknow! 🎓\n\n📍 Expected graduation: May 2027\n🏆 100% Scholarship recipient\n📚 Coursework: Data Structures, Algorithms, DBMS, Operating Systems, AI/ML, OOP, Computer Networks\n\nMy academic foundation from JNV + university coursework prepares me well for real-world challenges!"
  ],

  // Project questions
  "project|portfolio|build|create|work": [
    "I've built several impactful data-driven projects:\n\n1️⃣ HomeFinder - Property recommendation platform with REST APIs and smart filtering\n2️⃣ LeetCode Student Progress Tracking System - Analyzes coding performance, tracks progress, generates insights\n3️⃣ LDU Factorization - Mathematical computing tool with step-by-step results\n\nEach focuses on real-world problem-solving, scalability, and user experience!"
  ],

  // AI/ML questions
  "ai|machine learning|ml|neural|deep learning": [
    "AI/ML fascinates me! 🤖 I'm actively enhancing my skills:\n\n• Studying algorithms and data structures deeply\n• Implementing ML models practically\n• Analyzing patterns in real data (IPL analysis, student tracking)\n• Building predictive systems\n\nMy goal: Create AI-driven solutions that solve real-world challenges at scale!"
  ],

  // Goals/Career questions
  "goal|career|future|ambition|plan|aspiration": [
    "My long-term vision: Become a skilled software engineer building impactful solutions! 🎯\n\nFocus areas:\n🎯 Backend development & system design\n🎯 AI-driven applications\n🎯 Scalable, maintainable code\n\nI'm driven to learn new technologies, accept challenges, and contribute meaningfully to the tech industry while maintaining strong ethics! 💪"
  ],

  // Interests questions
  "interest|passionate|like|enjoy": [
    "I'm passionate about:\n\n✨ Full-stack web development\n✨ AI and Machine Learning\n✨ Data Structures & Algorithms\n✨ Database optimization\n✨ REST API design\n✨ Problem-solving through code\n✨ Building scalable systems\n✨ Continuous learning and growth"
  ],

  // Communication/Soft skills & Leadership
  "communication|team|collaboration|leadership|soft skill|discipline": [
    "Strong soft skills drive my success! 💬\n\n📊 JNV & NCC Background:\n• Leadership qualities developed through NCC 'B' Certificate\n• Discipline from competitive academic environment\n• Teamwork through collaborative projects\n\n✨ Current Focus:\n• Clear, effective communication in teamwork\n• Presentations and professional environments\n• Self-motivated, independent & collaborative work\n\nI believe great software comes from great teamwork! 🤝"
  ],

  // Technology specific
  "python|java|javascript|react|node|typescript|postgresql|fastapi|mysql": [
    "Great tech question! I have hands-on experience across the modern tech stack:\n\n• Python: Data analysis, backend development (FastAPI, Django)\n• Java: OOP principles, competitive programming\n• JavaScript/TypeScript: React frontends, Node.js backends\n• Databases: PostgreSQL, MySQL with proper design\n\nWhat specific technology interests you? 🔧"
  ],

  // Experience questions
  "experience|background|history": [
    "My journey combines academics with hands-on practice:\n\n🎓 JNV Mahoba → Strong problem-solving foundation (80%+ grades)\n🎓 Sitare University → Deep CS fundamentals + 100% scholarship\n💻 Projects → Full-stack web apps with real data\n🏆 NCC 'B' Certificate → Leadership & discipline\n\nI'm eager to apply this blend of theory and practice to real-world challenges! 🚀"
  ],

  // Greeting
  "hello|hi|hey|greetings": [
    "Hey there! 👋 Welcome! I'm Guman Singh Rajpoot. Ask me anything about my background, education, projects, skills, or goals! What interests you?"
  ],

  // Thanks
  "thank|thanks|appreciated|grateful": [
    "You're welcome! 😊 Happy to share more about my journey. Feel free to ask anything else!"
  ],

  // How are you / Feeling questions
  "how are you|how are you doing|how's it going|how's life": [
    "I'm doing great, thanks for asking! 😊 I'm excited about my journey at Sitare University and the projects I'm building. Currently focused on deepening my AI/ML skills and creating scalable applications. Life is good! 🚀",
    "Thanks for asking! 💫 I'm feeling energized and motivated. Balancing my B.Tech coursework, working on meaningful projects, and continuously learning new technologies. It's a fulfilling journey! 🎓",
    "Doing well! 😄 Just grinding away on my tech skills and building real-world projects. The combination of JNV's discipline and Sitare's academic rigor keeps me focused and driven. How about you?"
  ],

  // Feeling questions
  "feeling|mood|how do you feel": [
    "I'm feeling amazing! 😄 Passionate about tech, grateful for my scholarship at Sitare, and excited about the projects I'm building. Every day brings new learning opportunities. It's an incredible time to be building in tech! 💪",
    "Honestly, I'm in a great place mentally! 🌟 The discipline from JNV and leadership qualities from NCC keep me grounded. I'm happy when working on problems that matter and learning new things. Right now? Really happy! 😊",
    "Feeling energized and focused! ⚡ I love what I do - coding, problem-solving, learning. My goals in backend development and AI/ML drive me forward every day. Can't ask for better motivation!"
  ],

  // Are you happy
  "happy|satisfied|content|love what": [
    "Absolutely! 🎉 I'm genuinely happy. I love what I'm doing - building applications, learning AI/ML, and working toward becoming a skilled software engineer. The NCC discipline and JNV foundation keep me grounded while pursuing my dreams! 😊",
    "Yes, very much! 💝 I'm living my passion - tech, problem-solving, continuous learning. Being a 100% scholarship holder at Sitare University is a dream, and I'm making the most of it. This happiness fuels my drive to create impact! 🚀",
    "I am! 🌈 There's something magical about being a software engineer in the making. Every challenge I solve, every project I build, every new technology I learn - it all adds up to genuine happiness and purpose! 💪"
  ],

  // Personal/casual questions
  "what do you like|favorite|what excites|what motivates": [
    "What excites me most? 🤩\n\n1️⃣ Building full-stack applications from scratch\n2️⃣ Diving deep into AI/ML challenges\n3️⃣ Solving real-world problems with code\n4️⃣ Learning new technologies\n5️⃣ Leading teams (from my NCC experience)\n\nIt's the blend of creativity, logic, and impact that motivates me daily! 💪"
  ],

  // Dreams/Vision
  "dream|vision|future|what's your": [
    "My dream? 🎯 Become a skilled software engineer building impactful solutions at scale!\n\nSpecifically:\n🚀 Master backend architecture & AI-driven systems\n🚀 Lead meaningful tech projects\n🚀 Contribute to innovations that solve real problems\n🚀 Mentor others in their tech journey\n\nI want to make a lasting impact in tech while maintaining strong ethics! 💫"
  ]
};

const generateResponse = (userMessage: string): string => {
  const lowerMsg = userMessage.toLowerCase().trim();
  
  // Find best matching keyword
  for (const [keywords, responses] of Object.entries(keywordResponses)) {
    const keywordArray = keywords.split("|");
    if (keywordArray.some(keyword => lowerMsg.includes(keyword))) {
      return responses[Math.floor(Math.random() * responses.length)];
    }
  }

  // Default responses for various question types
  if (lowerMsg.endsWith("?")) {
    const defaultQuestionResponses = [
      "That's an interesting question! I'd love to help, but could you be more specific? Ask me about my skills, projects, education, or goals! 🤔",
      "Great question! Could you narrow it down? I'm happy to discuss my background, tech stack, or career aspirations! 💡",
      "Hmm, interesting! Feel free to ask about specific areas like my experience, skills, or what I'm working on! 🚀"
    ];
    return defaultQuestionResponses[Math.floor(Math.random() * defaultQuestionResponses.length)];
  }

  // Default fallback
  const fallbackResponses = [
    "That's a great point! Ask me more about my skills, projects, or goals, and I'll be happy to share! 😊",
    "Interesting! Feel free to ask me anything about my background or tech interests! 🌟",
    "I appreciate that! Is there something specific about my experience or projects you'd like to know? 💬"
  ];
  return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
};

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    { 
      id: 1, 
      sender: "Guman", 
      content: "Hi! I'm Guman Singh Rajpoot. 👋 Welcome to my chat! Ask me anything about my background, skills, projects, or career goals. I'm here to share my journey! 🚀", 
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      type: "received" 
    },
  ]);
  const [msgInput, setMsgInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!msgInput.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      sender: "You",
      content: msgInput,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      type: "sent",
    };

    setMessages(prev => [...prev, userMessage]);
    setMsgInput("");
    setIsLoading(true);

    // Add typing indicator
    const typingMessage: Message = {
      id: messages.length + 2,
      sender: "Guman",
      content: "typing",
      time: "",
      type: "typing"
    };
    setMessages(prev => [...prev, typingMessage]);

    // Simulate typing delay for more natural feel
    const delay = Math.random() * 800 + 400; // 400-1200ms
    setTimeout(() => {
      const botResponse: Message = {
        id: messages.length + 3,
        sender: "Guman",
        content: generateResponse(msgInput),
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        type: "received",
      };
      
      setMessages(prev => {
        const filtered = prev.filter(m => m.type !== "typing");
        return [...filtered, botResponse];
      });
      setIsLoading(false);
    }, delay);
  };

  const handleSuggestedTopic = (topic: string) => {
    setMsgInput(topic);
    setTimeout(() => {
      handleSendMessage();
    }, 0);
  };

  return (
    <MainLayout>
      <div className="h-[calc(100vh-6rem)] grid grid-cols-12 gap-6">
        {/* Info Panel */}
        <div className="col-span-12 md:col-span-4 lg:col-span-3 glass-card flex flex-col rounded-xl overflow-hidden">
          <div className="p-6 border-b border-border text-center">
            <div className="h-20 w-20 rounded-full bg-gradient-to-br from-primary to-secondary mx-auto mb-4 flex items-center justify-center shadow-lg shadow-primary/50">
              <span className="text-2xl font-display font-bold text-white">GR</span>
            </div>
            <h2 className="font-display font-bold text-lg">Guman Singh Rajpoot</h2>
            <p className="text-sm text-primary font-medium">B.Tech CSE Student</p>
            <p className="text-xs text-muted-foreground mt-1">Sitare University, Lucknow</p>
          </div>

          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">💻 Tech Stack</h3>
                <div className="flex flex-wrap gap-1.5">
                  {["Python", "Java", "JavaScript", "React", "Node.js", "PostgreSQL"].map((skill) => (
                    <span key={skill} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium hover:bg-primary/20 transition-colors cursor-default">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">🏆 Achievements</h3>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <p>🎖️ NCC 'B' Certificate</p>
                  <p>🎓 100% Scholarship @ Sitare</p>
                  <p>🏅 JNV Mahoba: 84% (12th)</p>
                </div>
              </div>

              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">📍 Background</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  JNV Mahoba → Sitare University (CSE, Lucknow)
                </p>
              </div>

              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">🎯 Goal</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Skilled software engineer in backend development and AI systems
                </p>
              </div>

              <div className="pt-2 border-t border-border">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">❓ Try Asking</h3>
                <div className="space-y-2">
                  {suggestedTopics.map((topic, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSuggestedTopic(topic)}
                      disabled={isLoading}
                      className="w-full text-left text-xs p-2 rounded-lg bg-primary/5 hover:bg-primary/10 text-muted-foreground hover:text-foreground transition-all disabled:opacity-50 disabled:cursor-not-allowed border border-primary/20 hover:border-primary/40"
                    >
                      {topic}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </ScrollArea>
        </div>

        {/* Chat Window */}
        <div className="col-span-12 md:col-span-8 lg:col-span-9 glass-card flex flex-col rounded-xl overflow-hidden">
          {/* Header */}
          <div className="p-4 border-b border-border flex justify-between items-center bg-background/50 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white font-bold">GR</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-display font-bold text-sm">Guman Singh Rajpoot</h3>
                <p className="text-xs text-green-500 flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" /> Online
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-foreground hover:bg-primary/10"><Phone className="h-4 w-4" /></Button>
              <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-foreground hover:bg-primary/10"><Video className="h-4 w-4" /></Button>
              <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-foreground hover:bg-primary/10"><MoreVertical className="h-4 w-4" /></Button>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea ref={scrollRef} className="flex-1 p-6 bg-gradient-to-b from-transparent to-black/20">
            <div className="space-y-4">
              {messages.length === 1 && (
                <div className="flex justify-center py-8">
                  <div className="text-center">
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
                      <MessageCircle className="h-6 w-6 text-primary" />
                    </div>
                    <p className="text-sm text-muted-foreground">Start a conversation! Pick a topic or ask anything.</p>
                  </div>
                </div>
              )}
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.type === 'sent' ? 'justify-end' : 'justify-start'}`}>
                  {msg.type === 'typing' ? (
                    <div className="flex items-center gap-2">
                      <Avatar>
                        <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-xs">GR</AvatarFallback>
                      </Avatar>
                      <div className="bg-card border border-border rounded-2xl px-4 py-3 rounded-bl-none">
                        <div className="flex gap-1">
                          <div className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0s" }} />
                          <div className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0.2s" }} />
                          <div className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0.4s" }} />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className={`max-w-[75%] rounded-2xl p-4 shadow-sm ${
                      msg.type === 'sent'
                        ? 'bg-primary text-primary-foreground rounded-br-none'
                        : 'bg-card border border-border rounded-bl-none'
                    }`}>
                      <p className="text-sm leading-relaxed whitespace-pre-line">{msg.content}</p>
                      <p className={`text-[10px] mt-2 text-right ${msg.type === 'sent' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                        {msg.time}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="p-4 bg-background/50 border-t border-border">
            <div className="flex items-center gap-2">
              <Input
                className="flex-1 bg-background border-input focus-visible:ring-primary"
                placeholder="Ask me anything..."
                value={msgInput}
                onChange={(e) => setMsgInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSendMessage()}
                disabled={isLoading}
              />
              <Button
                size="icon"
                className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full shadow-lg shadow-primary/20 disabled:opacity-50"
                onClick={handleSendMessage}
                disabled={isLoading || !msgInput.trim()}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
